//#include "hello.h"

#include "stdio.h"

int main(int argc, char *argv[])
{
	char* what = "sis hello !"; //Hello::getSay();
	printf("%s\n", what);
}
